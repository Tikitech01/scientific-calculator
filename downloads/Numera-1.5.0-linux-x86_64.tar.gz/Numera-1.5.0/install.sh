#!/bin/bash
# Installs Numera for the current user (no root needed).
set -e
cd "$(dirname "$0")"
install -Dm755 numera "$HOME/.local/bin/numera"
install -Dm644 icon-256.png "$HOME/.local/share/icons/hicolor/256x256/apps/numera.png"
install -Dm644 numera.desktop "$HOME/.local/share/applications/numera.desktop"
sed -i "s|^Exec=.*|Exec=$HOME/.local/bin/numera|" "$HOME/.local/share/applications/numera.desktop"
echo "Installed. Find Numera in your applications menu, or run: $HOME/.local/bin/numera"
