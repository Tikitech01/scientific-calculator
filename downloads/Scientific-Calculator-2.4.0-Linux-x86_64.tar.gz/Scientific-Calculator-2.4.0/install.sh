#!/bin/bash
# Installs Scientific Calculator for the current user (no root needed).
set -e
cd "$(dirname "$0")"
install -Dm755 scientific-calculator "$HOME/.local/bin/scientific-calculator"
install -Dm644 icon-256.png "$HOME/.local/share/icons/hicolor/256x256/apps/scientific-calculator.png"
install -Dm644 scientific-calculator.desktop "$HOME/.local/share/applications/scientific-calculator.desktop"
sed -i "s|^Exec=.*|Exec=$HOME/.local/bin/scientific-calculator|" "$HOME/.local/share/applications/scientific-calculator.desktop"
echo "Installed. Find Scientific Calculator in your applications menu, or run: $HOME/.local/bin/scientific-calculator"
